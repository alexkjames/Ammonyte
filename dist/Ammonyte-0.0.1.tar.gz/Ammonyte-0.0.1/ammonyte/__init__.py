# -*- coding: utf-8 -*-

import ammonyte.utils as utils
from .core import *

# get the version
from importlib.metadata import version
__version__ = version('ammonyte')